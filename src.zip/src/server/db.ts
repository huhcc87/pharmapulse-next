// Re-export prisma for compatibility
export { prisma } from "./prisma";

